package com.pawana.hello.vo;

public class Student {
	public Student() {
		super();
	}

	private String name;

	public String getName() {
		return name;
	}

	public Student(String name) {
		super();
		this.name = name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
